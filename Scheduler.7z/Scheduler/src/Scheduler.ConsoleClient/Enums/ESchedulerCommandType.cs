﻿namespace Scheduler.ConsoleClient
{
    public enum ESchedulerCommandType
    {
        Add = 1,
        Edit = 2,
        Delete = 3,
        Sort = 4,
        Close = 5,
    }
}