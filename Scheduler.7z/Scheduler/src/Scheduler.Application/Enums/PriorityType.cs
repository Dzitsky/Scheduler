﻿namespace Scheduler.Application.Enums
{
    public enum PriorityType
    {
        Normal = 1,
        Middle = 2,
        High = 3,
    }
}